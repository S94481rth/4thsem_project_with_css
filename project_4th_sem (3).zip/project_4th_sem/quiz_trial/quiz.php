<?php
    session_start();
    include('connection.php');
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $_SESSION['subject'] = $_POST['subject'];
    }
    
    $questionNumber =1 ;
    $query = "select * from questions where QuestionID = '$questionNumber'";
    $result = mysqli_query($con,$query);

    $ques_data = mysqli_fetch_assoc($result);
    echo "question is :  " . $ques_data['Question'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Choose subject to take quiz from..</h1>
    <form method="post" action="demo.php">
        <input type="radio" name="subject" value="physics"> physics<br>
        <input type="radio" name="subject" value="chemistry"> chemistry<br>
        <input type="radio" name="subject" value="mathematics"> mathematics<br>
        <input type="submit" value="Take Quiz">
    </form>
    <h3><?php echo "your option was :  " . $_SESSION['subject'] . " "; ?> </h3>
</body>
</html>