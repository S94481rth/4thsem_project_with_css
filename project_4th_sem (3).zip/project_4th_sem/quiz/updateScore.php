<?php
    session_start();
    $SESSION;

    include("db.php");
    include("../login/functions.php");
    $user_data = checkLogin($connection);



    
    try{
        $query = "INSERT INTO performance(USN,marks,Subject) values ('" . $user_data['USN'] . "' , ' " . $_SESSION['score'] . " ', 'Computer');";
        mysqli_query($connection,$query);
        unset($_SESSION['score']);
    }   
    catch(exception $e){
        echo "Cannot upadate this score since your userID has already taken this test!
        <br>You Can take the test only once! ";
    } 
    //INSERT INTO performance(USN,marks,Subject) values ('$user_data['USN']' , '$_SESSION['score'] ', ' ComputerScience ')
?>



<html>
    <head>
    <link rel="stylesheet" type="text/css" href="css/style.css">

        <style>
            body{
            font-family: arial;
            font-size: 15px;
            line-height: 1.6em;
            background : linear-gradient(to right,#4285F4,#9CECFB);
            font-family: "Roboto",sans-serif;
            }
            .button{
                width: 150px;
                height : 20px;
                border-radius: 5px; 
                background-color: #00c3ff; /* Green */
            }
        </style>

    </head>
    <body>
        <a href="../login/homePage.php" class="button" >Home Page </a>
    </body>

</html>



