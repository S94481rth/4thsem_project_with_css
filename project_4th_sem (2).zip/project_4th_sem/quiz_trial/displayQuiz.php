<?php
 
    session_start();
    include('connection.php');
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $_SESSION['subject'] = $_POST['subject'];
    }
 
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $questionID = 0;
        $score = 0;
        $chosen = $_POST['options'];
        $query1 = " select * from questions where Subject = '" . $_SESSION['subject'] . "';";
        $query2 = " select * from options where Subject = '" . $_SESSION['subject'] . "';";
        $result1 = mysqli_query($con,$query1);
        $result2 = mysqli_query($con,$query2);
        $ques_data = mysqli_fetch_assoc($result1); 
        $option_data = mysqli_fetch_assoc($result2);
    
        while($questionID  < 5){
            echo " " . $questionID . " ";
            $question = $ques_data[$questionID]['Question'];
            $a = $option_data[$questionID]['a'];
            $b = $option_data[$questionID]['b'];
            $c = $option_data[$questionID]['c'];
            $d = $option_data[$questionID]['d'];
            $correct = $option_data[$questionID]['correct'];    
            if(isset($chosen)){
                if($chosen === $option_data[$questionID]['correct']){
                    $score = $score + 1;        
                }
                unset($chosen);
            }
            $questionID = $questionID + 1;
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <h1>Question</h1>
        <input type="radio" name="options" value="a"><?php echo "A: " . $a . " "; ?>  <br>
        <input type="radio" name="options" value="b"><?php echo "B: " . $b . " "; ?> <br>
        <input type="radio" name="options" value="c"><?php echo "C: " . $c . " "; ?> <br>
        <input type="radio" name="options" value="d"><?php echo "D: " . $d . " "; ?> <br>
        <input type="submit" value="Next">
</form>
</body>
</html>