<?php
    $dbhost = "localhost";
    $dbusername = "root";
    $dbpassword = "sura";
    $dbname = "quizby";

    if(!$con = mysqli_connect($dbhost,$dbusername,$dbpassword,$dbname)){
        die("Connection failed :(");
    }