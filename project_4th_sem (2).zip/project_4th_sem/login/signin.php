<?php
    session_start();
    
    include("functions.php");
    include("connection.php");

    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $USN = $_POST['USN'];
        $password = $_POST['password'];
        $name = $_POST['name'];
        $phoneNumber = $_POST['phoneNumber'];
        if(!empty($USN) && !empty($password) && !empty($name) && !empty($phoneNumber)){
            try{
              $query = "insert into student_info(name,USN,password,phoneNo) values ('$name','$USN','$password','$phoneNumber')";
              mysqli_query($con,$query);
              header("Location: homePage.php");
              die;  
            }catch(Exception $e){
              echo "usn should be exactly 10 characters OR usn already exists!";
            }
        }
        else{
          echo "Please do not leave any field empty! ";
        }
    }
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <title>Document</title>
</head>
<body>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <h1>SignIn Page</h1>
        Name : <input type="text" name="name"><br>
        USN : <input type="text" name="USN" id=""><br>
        Password : <input type="password" name="password"><br>
        Phone Number : <input type="text" name="phoneNumber"><br>
        
        <input type="submit" value="Sign In" class="button"><br>
        <a href="login.php" class="button">Have an account? Login</a>
    </form>

</body>
</html>