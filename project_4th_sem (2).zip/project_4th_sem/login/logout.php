<?php
    session_start();
    if(isset($_SESSION['USN'])){
        unset($_SESSION['USN']);            
    }
    header("Location: login.php");
    die;
?>
