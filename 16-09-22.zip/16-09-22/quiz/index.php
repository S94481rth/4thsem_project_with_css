<html>
<head>
	<title>PHP Quizer</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<style>
	body{
	font-family: arial;
	font-size: 15px;
	line-height: 1.6em;
	background : linear-gradient(to right,#4285F4,#9CECFB);
	font-family: "Roboto",sans-serif;
	}
	h2,p{
		color: black;
	}
</style>
</head>
<body>

	<header>
		<div class="container">
			<p>PHP Quizer</p>
		</div>
	</header>

	<main>
    <div class = "menu">


<a href="main.php" class="button">Take Quiz</a>
<a href="verify.php" class="button">Add questions</a>
</div>
	</main>




</body>
</html>
