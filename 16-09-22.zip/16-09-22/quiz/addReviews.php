<?php  include 'db.php';

if(isset($_POST['submit'])){
	//$question_number = $_POST['question_number'];
	$usn = $_POST['usn'];
	$name = $_POST['name'];
	// Choice Array
    $feedback = $_POST['feedback'];

 // First Query for Questions Table

	$query = "INSERT INTO testimonials (";
	$query .= "USN, reviews,name )";
	$query .= "VALUES (";
	$query .= " '{$usn}','{$feedback}','{$name}' ";
	$query .= ")";

	$result = mysqli_query($connection,$query);
	$message = "Thank You For Your Feedback";
	//Validate First Query
	// if($result){
	// 	foreach($choice as $option => $value){
	// 		if($value != ""){
	// 			if($correct_choice == $option){
	// 				$is_correct = 1;
	// 			}else{
	// 				$is_correct = 0;
	// 			}
			


	// 			//Second Query for Choices Table
	// 			$query = "INSERT INTO options (";
	// 			$query .= "question_number,is_correct,coption)";
	// 			$query .= " VALUES (";
	// 			$query .=  "'{$question_number}','{$is_correct}','{$value}' ";
	// 			$query .= ")";

	// 			$insert_row = mysqli_query($connection,$query);
	// 			// Validate Insertion of Choices

	// 			if($insert_row){
	// 				continue;
	// 			}else{
	// 				die("2nd Query for Choices could not be executed" . $query);
					
	// 			}

	// 		}
	// 	}
	// 	$message = "Question has been added successfully";
	// }

	




}

		$query = "SELECT * FROM questions";
		$questions = mysqli_query($connection,$query);
		$total = mysqli_num_rows($questions);
		$next = $total+1;
		

?>
<html>
<head>
	<title>PHP Quizer</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<style>
	body{
	font-family: arial;
	font-size: 15px;
	line-height: 1.6em;
	background : linear-gradient(to right,#42f483,#77e806);
	font-family: "Roboto",sans-serif;
	}
    h2,p{
		color: black;
	}
    
</style>
<body>

	<header>
		<div class="container">
			<p>PHP Quizer</p>
		</div>
	</header>

	<main>
			<div class="container">
				<h2>Add A Question</h2>
				<?php if(isset($message)){
					echo "<h4>" . $message . "</h4>";
				} ?>
								
				<form method="POST" action="addReviews.php">

						<p>
							<label>Enter USN</label>
							<input type="text" name="usn">
						</p>
						<p>
							<label>Name</label>
							<input type="text" name="name">
						</p>
						<p>
							<label>Feedback</label>
							<input type="text" name="feedback" style="height:60px; width:400px;">
                            
						</p>
                        
						<input type="submit" name="submit" value ="submit">
						<a href="../login/homePage.php">Home</a>

				</form>
			</div>

	</main>











</body>
</html>