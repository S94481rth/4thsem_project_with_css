<?php 

session_start();

?>

<html>
<head>
	<title>PHP Quizer</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<style>
	body{
	font-family: arial;
	font-size: 15px;
	line-height: 1.6em;
	background : linear-gradient(to right,#4285F4,#9CECFB);
	font-family: "Roboto",sans-serif;
	}
	h2,p{
		color: black;
	}
</style>
</head>
<body>

	<header>
		<div class="container">
			<p>PHP Quizer</p>
		</div>
	</header>

	<main>
			<div class="container">
				<h2>Your Result</h2>
				<p>Congratulation You have completed this test succesfully.</p>
				<p>Your <strong>Score</strong> is <?php echo $_SESSION['score']; ?>  </p>

				
			</div>

	</main>




	<a href="updateScore.php">Exit</a>





</body>
</html>