<?php
    session_start();
    include("functions.php");
    include("connection.php");
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $_SESSION['password'] = $_POST['password'];
        $_SESSION['admin_id'] = $_POST['admin_id'];
        if(!empty($_SESSION['password'])){
                if($_SESSION['password'] === 'adminlogin' && $_SESSION['admin_id'] === 'adminlogin'){
                  header("Location: ../quiz/add.php");
                  die; 
                }
              echo "Wrong Password";
        }
        else{
          echo "Please do not leave any field empty! ";
        }
    }
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/style.css">

    <title>Document</title>
</head>
<body>
  <div class= "container">
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <h1>Login Page</h1>

       Admin ID : <input type="text" name="admin_id" id=""><br>
        Password : <br><input type="password" name="password" id=""><br>
        <input type="submit" class = "submit" value="Login" class="button"><br>
        <a href="login.php" class="createAccount">Student Login</a>
    </form>
  </div>
</body>
</html>