<?php
    session_start();
    $SESSION;

    include("db.php");
    include("functions.php");
    $user_data = checkLogin($connection);
    
    // $query = "INSERT INTO testimonials (";
	// $query .= "USN, reviews,name )";
	// $query .= "VALUES (";
	// $query .= " '{$usn}','{$feedback}','{$name}' ";
	// $query .= ")";

    $query = "delete from student_info where USN = '{$user_data['USN']}'";
    $result = mysqli_query($connection,$query);
    session_start();
    if(isset($_SESSION['USN'])){
        unset($_SESSION['USN']);            
    }
    header("Location: login.php");
    die;
?>