<?php
    session_start();
    $SESSION;

    include("connection.php");
    include("functions.php");
    $user_data = checkLogin($con);
    
  
?>


<!DOCTYPE html>
<html lang="en">    
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <title>Document</title>
</head>
<body>
    <center><h1>QuizBy</h1></center>   <a href="deleteAccount.php" class="delete">deleteAccount</a><br>
    <center><h1>Welcome Home! <?php echo " " . $user_data['name'] . " " ?>  </h1></center>
    <br><br><br>
    <center><a href="../quiz/main.php" class="button">Take quiz</a>
    <a href="../quiz/addReviews.php" class="button">Give Feedback</a>
    <a href="logout.php" class="button">Logout</a></center>

    <!--<a href="../quiz/viewReviews.php" class= "button">View Feedback</a>//-->
</body>
</html>